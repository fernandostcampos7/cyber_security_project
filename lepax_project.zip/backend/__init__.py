"""
LePax backend package.
Contains the Flask app, database models, and API logic.
"""
